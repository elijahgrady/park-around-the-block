<?php

    $enviroment_dict;
    $operation_type = -1; // 1 for creating a new customer profile, 2 for creating a new payment profile

    //get JSON from QB webhook: is contains name - value pairs
    $json_env = (file_get_contents('VPC-IC-PROD-sdhack.postman_environment.json'));
    $json_a = json_decode($json_env, true);

    foreach ($json_a["values"] as $curr_data){
        $enviroment_dict[$curr_data["key"]] = $curr_data["value"];
    }

    //var_dump($enviroment_dict);


    function get_all_assets_from_file(){
        //get JSON from QB webhook: is contains name - value pairs
        $json_env = (file_get_contents('all_assets.json'));
        $json_a = json_decode($json_env, true);

        foreach ($json_a["content"] as $curr_data) {
            $enviroment_dict[$curr_data["assetUid"]] = ["parentAssetUid" => $curr_data["parentAssetUid"],
                "eventTypes" => $curr_data["eventTypes"],
                "mediaType" => $curr_data["mediaType"],
                "assetType" => $curr_data["assetType"],
                "coordinates" => $curr_data["coordinates"]];
        }
        return $enviroment_dict;
    }

    ///
    /// API calls
    ///

    /*
    * This function creates a curl handeler to send an HTTP GET to Box
    * @param uri - uri of the api call
    * @param bearer_token - a token used for Box authorisation
    * @return $ch - a curl handeler that is ready to be executed
    */

    function create_curl_handler_authorize_GET()
    {
        global $enviroment_dict;

        //create the request excluding body
        $url = $enviroment_dict["UAAURL"];

        $headers = array(
            "GET " . "/oauth/token?grant_type=client_credentials" . " HTTP/1.1",
            "Host: " . "624eff02-dbb1-4c6c-90bc-fa85a29e5fa8.predix-uaa.run.aws-usw02-pr.ice.predix.io",
            "Authorization: Basic c2QuaGFja2F0aG9uOkVRUEBFQGk0djY=",
        );

        //curl portion
        //initialize curl
        $ch = curl_init();

        //set curl options
        curl_setopt($ch, CURLOPT_URL, $url."?grant_type=client_credentials");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); //dont output what you recieve, store for procession
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);

        return ($ch);
    }

    function get_token(){
        //set up curl and execute it
        $ch = create_curl_handler_authorize_GET();
        $response = curl_exec($ch);
        $response = preg_replace('/\xEF\xBB\xBF/', '', $response);

        //handle the response
        $err = curl_errno($ch);
        if ($err > 0) {
            print_r("Error sending curl");
            exit();
        }
        $response_decoded = json_decode($response, true);
        $errno = json_last_error();
        if ($errno != JSON_ERROR_NONE) {
            print_r("\nError encountered decoding JSON: " . $errno . "\n");
            print_r(json_last_error_msg() . "\n");
            exit();
        }
        curl_close($ch);
        return $response_decoded["access_token"];
    }

    function get_all_assets($token){
        global $enviroment_dict;
        //create the request excluding body
        $url = $enviroment_dict["metadataurl"];

        $headers = array(
            "Authorization: Bearer ".$token,
            "Predix-Zone-Id: "."SD-IE-TRAFFIC",
        );

        //curl portion
        //initialize curl
        $ch = curl_init();

        //set curl options
        curl_setopt($ch, CURLOPT_URL, $url."/assets/search?bbox=33.077762:-117.663817,32.559574:-116.584410&amp;page=0&amp;size=200&amp;q=assetType:CAMERA");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); //dont output what you recieve, store for procession
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);

        $response = curl_exec($ch);
        $response = preg_replace('/\xEF\xBB\xBF/', '', $response);

        print($response);
        //handle the response
        $err = curl_errno($ch);
        if ($err > 0) {
            print_r("Error sending curl");
            exit();
        }
        $response_decoded = json_decode($response, true);
        $errno = json_last_error();
        if ($errno != JSON_ERROR_NONE) {
            print_r("\nError encountered decoding JSON: " . $errno . "\n");
            print_r(json_last_error_msg() . "\n");
            exit();
        }
        curl_close($ch);
        return $response_decoded;

    }

    function get_all_pkin_month($token){
        global $enviroment_dict;
        //create the request excluding body
        $url = $enviroment_dict["eventurl"];
        $end_time = time()."000";
        $start_time = $end_time - 31556926;

        $headers = array(
            "Authorization: Bearer ".$token,
            "Predix-Zone-Id: "."SD-IE-PARKING",
        );

        //curl portion
        //initialize curl
        $ch = curl_init();

        //set curl options
        curl_setopt($ch, CURLOPT_URL, $url."/locations/events?bbox=33.077762:-117.663817,32.559574:-116.584410&locationType=PARKING_ZONE&eventType=PKIN&startTime=".$start_time."&endTime=".$end_time);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); //dont output what you recieve, store for procession
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);

        $response = curl_exec($ch);
        $response = preg_replace('/\xEF\xBB\xBF/', '', $response);

        print($response);
        //handle the response
        $err = curl_errno($ch);
        if ($err > 0) {
            print_r("Error sending curl");
            exit();
        }
        $response_decoded = json_decode($response, true);
        $errno = json_last_error();
        if ($errno != JSON_ERROR_NONE) {
            print_r("\nError encountered decoding JSON: " . $errno . "\n");
            print_r(json_last_error_msg() . "\n");
            exit();
        }
        curl_close($ch);
        return $response_decoded;

    }

    function get_all_pkout_month($token){
        global $enviroment_dict;
        $url = $enviroment_dict["eventurl"];
        $end_time = time()."000";
        $start_time = $end_time - 31556926;

        $headers = array(
            "Authorization: Bearer ".$token,
            "Predix-Zone-Id: "."SD-IE-PARKING",
        );

        //curl portion
        //initialize curl
        $ch = curl_init();

        //set curl options
        curl_setopt($ch, CURLOPT_URL, $url."/locations/events?bbox=33.077762:-117.663817,32.559574:-116.584410&locationType=PARKING_ZONE&eventType=PKOUT&startTime=".$start_time."&endTime=".$end_time);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); //dont output what you recieve, store for procession
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);

        $response = curl_exec($ch);
        $response = preg_replace('/\xEF\xBB\xBF/', '', $response);

        print($response);
        //handle the response
        $err = curl_errno($ch);
        if ($err > 0) {
            print_r("Error sending curl");
            exit();
        }
        $response_decoded = json_decode($response, true);
        $errno = json_last_error();
        if ($errno != JSON_ERROR_NONE) {
            print_r("\nError encountered decoding JSON: " . $errno . "\n");
            print_r(json_last_error_msg() . "\n");
            exit();
        }
        curl_close($ch);
        return $response_decoded;

    }
    ////////////////////////////////////
    ///           Main body          ///
    ////////////////////////////////////


    $token = get_token();
    print_r($token);
    $assets_all = get_all_assets_from_file();
    $all_pkin_month = get_all_pkin_month($token);
    $all_pkout_month = get_all_pkout_month($token);
    print_r("++++++++++++++++++++\n");

    $pkin_dict = [];
    $pkout_dict = [];
    $taken_spots = [];

    foreach ($all_pkin_month["content"] as $curr_pkin){
        if (array_key_exists($curr_pkin["assetUid"], $pkin_dict)){
            if ($curr_pkin["timestamp"] > $pkin_dict[$curr_pkin["assetUid"]]["timestamp"]){
                $pkin_dict[$curr_pkin["assetUid"]] = ["timestamp" => $curr_pkin["timestamp"],
                    "geoCoordinates" => $curr_pkin["properties"]["geoCoordinates"]];
            }
        }
        $pkin_dict[$curr_pkin["assetUid"]] = ["timestamp" => $curr_pkin["timestamp"],
                                              "geoCoordinates" => $curr_pkin["properties"]["geoCoordinates"]];
    }

    foreach ($all_pkout_month["content"] as $curr_pkout){
        if (array_key_exists($curr_pkout["assetUid"], $pkout_dict)){
            if ($curr_pkout["timestamp"] > $pkout_dict[$curr_pkout["assetUid"]]["timestamp"]){
                $pkout_dict[$curr_pkout["assetUid"]] = ["timestamp" => $curr_pkout["timestamp"],
                    "geoCoordinates" => $curr_pkout["properties"]["geoCoordinates"]];
            }
        }
        $pkout_dict[$curr_pkout["assetUid"]] = ["timestamp" => $curr_pkout["timestamp"],
                                               "geoCoordinates" => $curr_pkout["properties"]["geoCoordinates"]];
    }

    $assets_open_geo;
    $assets_taken_geo;
    foreach ($all_pkin_month as $curr_id => $curr_pkin){
        if((array_key_exists($curr_id, $pkout_dict)) && ($pkin_dict[$curr_id]["timestamp"] < $pkout_dict[$curr_id]["timestamp"])){
        }
        else{
            $taken_spots[$curr_id] = $assets_all[$curr_id];
            $assets_taken_geo[] = $assets_all[$curr_id]["coordinates"];
        }
    }

    foreach ($assets_all as $key => $val){
        $assets_open_geo[] = $val["coordinates"];
    }

    $return = [$assets_open_geo, $assets_taken_geo];
    return($return);
?>




  
